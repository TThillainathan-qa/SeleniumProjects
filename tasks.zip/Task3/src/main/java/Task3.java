import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task3 {
WebDriver driver;
	
	@Before
	public void init() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				
	}
	@Test
	public void test() {
		driver.get("https://www.hl.co.uk/shares/stock-market-summary/ftse-100");
		
		WebElement rise = driver.findElement(By.id("view-constituents"));
		rise.click();
		
		WebElement riseText = driver.findElement(By.xpath("//*[@id=\"ls-row-LSE-L\"]/td[2]/a"));
		System.out.println(riseText.getText());
		
		WebElement fall = driver.findElement(By.xpath("//*[@id=\"view-constituents\"]/ul/li[3]/a/strong"));
		fall.click();
		
		WebElement fallText = driver.findElement(By.xpath("//*[@id=\"ls-row-IHG-L\"]/td[2]/a"));
		System.out.println(fallText.getText());
		//rise.getText();
		//System.out.println(rise.getText());
	}
	


}
